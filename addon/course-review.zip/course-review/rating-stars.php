
<div class="review-stars-rated">
	<div class="review-stars empty"></div>
	<div class="review-stars filled" style="width:<?php echo $rated * 20; ?>%;"></div>
</div>